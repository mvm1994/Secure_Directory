﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;

namespace WindowsFormsApplication4
{
    public partial class changepass : Form
    {
        DataSet1TableAdapters.file_tblTableAdapter f = new DataSet1TableAdapters.file_tblTableAdapter();
        DataSet1TableAdapters.login_tblTableAdapter l = new DataSet1TableAdapters.login_tblTableAdapter();
        public changepass()
        {
            InitializeComponent();
        }

        private string Sha256(string text)
        {
            StringBuilder sb = new StringBuilder();
            SHA256 hash = SHA256Managed.Create();
            Encoding enc = Encoding.UTF8;
            byte[] hashbyte = hash.ComputeHash(enc.GetBytes(text));

            foreach (byte b in hashbyte)
            {
                sb.Append(b.ToString("x2"));
            }
            return sb.ToString();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                textBox2.UseSystemPasswordChar = false;
                textBox3.UseSystemPasswordChar = false;
                textBox4.UseSystemPasswordChar = false;
            }
            else
            {
                textBox2.UseSystemPasswordChar = true;
                textBox3.UseSystemPasswordChar = true;
                textBox4.UseSystemPasswordChar = true;
            }
        }

        private async void button1_Click_1(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("شناسه کاربری خود را وارد نمایید");
                textBox1.Focus();
                return;
            }
            else if (textBox2.Text == "")
            {
                MessageBox.Show("کلمه عبور قدیم خود را وارد نمایید");
                textBox2.Focus();
                return;
            }
            else if (textBox3.Text == "")
            {
                MessageBox.Show("کلمه عبور جدید خود را وارد نمایید");
                textBox3.Focus();
                return;
            }
            else if (textBox3.Text != textBox4.Text)
            {
                MessageBox.Show("کلمه عبور جدید درست تکرار نشده است");
                textBox4.Text = "";
                textBox4.Focus();
                return;
            }
            else
            {
                string pid = Sha256(information.id);
                string[] files = Directory.GetFiles(@"E:\Archive" + @"\" + pid + "");

                string pswd = Sha256(textBox2.Text);
                int x = l.login(textBox1.Text,pswd).Value;
                if (x != 0)
                {
                    foreach (var file in files)
                    {
                        try
                        {
                            var mainTitle = Text;
                            Text = @"در حال رمزگشایی فایل ...";
                            var filePath = file;
                            var password = information.new_pass;
                            var file_bytes = File.ReadAllBytes(filePath);
                            var file_hash = SHA256.Create().ComputeHash(file_bytes);
                            string hash = file_hash.ToString();

                            var s = f.GetDataByadrs(filePath);
                            if (s.Rows.Count == 0)
                            {
                                File.Delete(filePath);
                                //f.del(Path.GetFileName(filePath));
                                break;
                            }
                            else
                            {
                                if (hash == s.Rows[0][3].ToString())
                                {
                                    // برای آن که برنامه در هنگام عملیات رمزگشایی قفل نشود
                                    //  متد زیر را با استفاده از Task فراخوانی می کنیم
                                    await Task.Run(() => AesCryptography.DecryptFile(filePath, password));
                                    Text = mainTitle;
                                    //MessageBox.Show(@"عملیات رمزگشایی با موفقیت انجام شد");
                                }
                            }

                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }
                    string pwd = Sha256(textBox3.Text);
                    l.changepass(pwd, textBox1.Text);
                    information.new_pass = textBox3.Text;

                    textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = "";
                    textBox1.Focus();
                    MessageBox.Show("تغییر رمز با موفقیت انجام شد");

                    foreach (var file in files)
                    {
                        try
                        {
                            var mainTitle = Text;
                            Text = @"در حال رمزگذاری فایل ...";
                            var filePath = file;
                            var password = information.new_pass;
                            var file_bytes = File.ReadAllBytes(filePath);
                            var file_hash = SHA256.Create().ComputeHash(file_bytes);
                            string hash = file_hash.ToString();

                            var s = f.GetDataByadrs(filePath);
                            if (s.Rows.Count == 0)
                            {
                                break;
                            }
                            else
                            {
                                if (hash == s.Rows[0][3].ToString())
                                {
                                    //برای آن که برنامه در هنگام عملیات رمزگذاری قفل نشود
                                    //  متد زیر را با استفاده از Task فراخوانی می کنیم
                                    await Task.Run(() => AesCryptography.EncryptFile(filePath, password));
                                    Text = mainTitle;
                                    //MessageBox.Show(@"عملیات رمزنگاری با موفقیت انجام شد");
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("نام کاربری یا کلمه عبور قدیم اشتباه وارد شده است");
                    textBox1.Text = textBox2.Text = "";
                    textBox1.Focus();
                    return;
                }
            }
        }
        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form2 f = new Form2();
            f.Show();
        }
    }
}
