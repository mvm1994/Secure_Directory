﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication4
{
    public static class information
    {
        public static string id;
        public static string new_pass;
        public static string fullpath;
        public static string filename;
        public static string path;
        public static string tmpadrs;
        public static string[] items;
    }
}
