﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Security.Cryptography;

namespace WindowsFormsApplication4
{
    public static class AesCryptography
    {
        /// <summary>
        /// برای رمزگذاری بایت ها استفاده می شود
        /// </summary>
        /// <param name="bytesToEncrypted">بایت های فایل یا متنی که باید رمزگذاری شود</param>
        /// <param name="passwordBytes">بایت های رشته ایی که به عنوان پسورد وارد شده است</param>
        /// <returns>آرایه ای از بایت ها</returns>
        private static byte[] AesEncrypt(byte[] bytesToEncrypted, byte[] passwordBytes)
        {
            byte[] encryptedBytes;
            var saltBytes = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 };

            using (var memoryStream = new MemoryStream())
            {
                using (var aes = new RijndaelManaged())
                {
                    aes.KeySize = 256;
                    aes.BlockSize = 128;

                    var key = new Rfc2898DeriveBytes(passwordBytes, saltBytes, 1000);
                    aes.Key = key.GetBytes(aes.KeySize / 8);
                    aes.IV = key.GetBytes(aes.BlockSize / 8);
                    aes.Mode = CipherMode.CBC;

                    using (var cs = new CryptoStream(memoryStream, aes.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(bytesToEncrypted, 0, bytesToEncrypted.Length);
                        cs.Close();
                    }

                    encryptedBytes = memoryStream.ToArray();
                }
            }

            return encryptedBytes;
        }

        /// <summary>
        /// برای رمزگشایی بایت ها استفاده می شود
        /// </summary>
        /// <param name="bytesToDecrypted">بایت های فایل یا متنی که باید رمزگشایی شود</param>
        /// <param name="passwordBytes">بایت های رشته ایی که به عنوان پسورد وارد شده است</param>
        /// <returns>آرایه ای از بایت ها</returns>
        private static byte[] AesDecrypt(byte[] bytesToDecrypted, byte[] passwordBytes)
        {
            byte[] decryptedBytes;
            var saltBytes = new byte[] { 1, 2, 3, 4, 5, 6, 7, 8 };

            using (var memoryStream = new MemoryStream())
            {
                using (var aes = new RijndaelManaged())
                {
                    aes.KeySize = 256;
                    aes.BlockSize = 128;

                    var key = new Rfc2898DeriveBytes(passwordBytes, saltBytes, 1000);
                    aes.Key = key.GetBytes(aes.KeySize / 8);
                    aes.IV = key.GetBytes(aes.BlockSize / 8);

                    aes.Mode = CipherMode.CBC;

                    using (var cs = new CryptoStream(memoryStream, aes.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(bytesToDecrypted, 0, bytesToDecrypted.Length);
                        cs.Close();
                    }
                    decryptedBytes = memoryStream.ToArray();
                }
            }

            return decryptedBytes;
        }

        /// <summary>
        /// برای رمزگذاری فایل استفاده می شود 
        /// </summary>
        /// <param name="filePath">آدرس فایلی که باید رمزگذاری شود</param>
        /// <param name="password">پسوردی که فایل باید بر اساس آن رمزگذاری می شود</param>
        public static void EncryptFile(string filePath, string password)
        {
            // بررسی آرگومان ها
            if (string.IsNullOrEmpty(filePath))
                throw new ArgumentNullException(nameof(filePath));
            if (string.IsNullOrEmpty(password))
                throw new ArgumentNullException(nameof(password));

            // گرفتن کل بایت های فایل
            var bytesToEncrypted = File.ReadAllBytes(filePath);
            // تبدیل پسورد به آرایه ای از بایت ها
            var passwordBytes = Encoding.UTF8.GetBytes(password);
            // تبدیل بایت های پسورد به Hash
            passwordBytes = SHA256.Create().ComputeHash(passwordBytes);
            // رمزگذاری بایت های فایل با استفاده از متد AesEncrypt
            var bytesEncrypted = AesEncrypt(bytesToEncrypted, passwordBytes);
            // نوشتن بایت ها رمزگذاری شده درون فایل
            File.WriteAllBytes(filePath, bytesEncrypted);
        }

        /// <summary>
        /// برای رمزگشایی فایل استفاده می شود
        /// </summary>
        /// <param name="filePath">آدرس فایل رمزگذاری شده با متد EncryptFile</param>
        /// <param name="password">پسوردی که فایل باید بر اساس آن رمزگشایی می شود</param>
        public static void DecryptFile(string filePath, string password)
        {
            // بررسی آرگومان ها
            if (string.IsNullOrEmpty(filePath))
                throw new ArgumentNullException(nameof(filePath));
            if (string.IsNullOrEmpty(password))
                throw new ArgumentNullException(nameof(password));

            // گرفتن کل بایت های فایل
            var bytesToDecrypted = File.ReadAllBytes(filePath);
            // تبدیل پسورد به آرایه ای از بایت ها
            var passwordBytes = Encoding.UTF8.GetBytes(password);
            // تبدیل بایت های پسورد به Hash
            passwordBytes = SHA256.Create().ComputeHash(passwordBytes);
            // رمزگشایی بایت های فایل با استفاده از متد AesDecrypt
            var bytesDecrypted = AesDecrypt(bytesToDecrypted, passwordBytes);
            // نوشتن بایت ها رمزگشایی شده درون فایل
            File.WriteAllBytes(filePath, bytesDecrypted);
        }
    }
}
