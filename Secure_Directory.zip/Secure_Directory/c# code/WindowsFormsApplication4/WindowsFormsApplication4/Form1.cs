﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;
namespace WindowsFormsApplication4
{
    public partial class Form1 : Form
    {
        DataSet1TableAdapters.login_tblTableAdapter l = new DataSet1TableAdapters.login_tblTableAdapter();

        public Form1()
        {
            InitializeComponent();
            notifyIcon1.Icon = this.Icon;
            notifyIcon1.Visible = true;
            notifyIcon1.ShowBalloonTip(10000, "پنل ورود", "خوش آمدید", ToolTipIcon.Info);
            notifyIcon1.Text = "جهت خروج کلیک کنید";
        }

        private string SHA256(string text)
        {
            StringBuilder sb = new StringBuilder();
            SHA256 hash = SHA256Managed.Create();
            Encoding enc = Encoding.UTF8;
            byte[] hashbyte = hash.ComputeHash(enc.GetBytes(text));

            foreach (byte b in hashbyte)
            {
                sb.Append(b.ToString("x2"));
            }
            return sb.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "")
            {
                MessageBox.Show("شناسه کاربری را وارد کنید");
                textBox1.Focus();
                return;
            }
            else if (textBox2.Text == "")
            {
                MessageBox.Show("کلمه عبور خود را وارد کنید");
                textBox2.Focus();
                return;
            }
            else
            {
                string pwd = SHA256(textBox2.Text);
                int d = l.login(textBox1.Text, pwd).Value;
                if (d==0)
                {
                    MessageBox.Show("شناسه کاربری یا کلمه عبور اشتباه است");
                    textBox1.Text = textBox2.Text = "";
                    textBox1.Focus();
                    return;
                }
                else
                {
                    information.id = textBox1.Text;
                    information.new_pass = textBox2.Text;
                    this.Hide();
                    Form2 f = new Form2();
                    f.Show();
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 f = new Form3();
            f.Show();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                textBox2.UseSystemPasswordChar = false;
            }
            else
            {
                textBox2.UseSystemPasswordChar = true;
            }
        }

        private void notifyIcon1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("آیا میخواهید از برنامه خارج شوید؟","خروج",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
