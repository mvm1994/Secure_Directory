﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;

namespace WindowsFormsApplication4
{
    public partial class Form3 : Form
    {
        DataSet1TableAdapters.login_tblTableAdapter l = new DataSet1TableAdapters.login_tblTableAdapter();
        public Form3()
        {
            InitializeComponent();
        }

        private string SHA256(string text)
        {
            StringBuilder sb = new StringBuilder();
            SHA256 hash = SHA256Managed.Create();
            Encoding enc = Encoding.UTF8;
            byte[] hashbyte = hash.ComputeHash(enc.GetBytes(text));

            foreach (byte b in hashbyte)
            {
                sb.Append(b.ToString("x2"));
            }
            return sb.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text=="")
            {
                MessageBox.Show("شناسه کاربری را وارد کنید");
                textBox1.Focus();
                return;
            }
            else if(textBox2.Text=="")
            {
                MessageBox.Show("کلمه عبور خود را وارد کنید");
                textBox2.Focus();
                return;
            }
            else
            {
                var d = l.GetDataByid(textBox1.Text);
                if (d.Rows.Count>0)
                {
                    MessageBox.Show("این شناسه کاربری در پایگاه داده موجود است");
                    textBox1.Text = textBox2.Text = "";
                    textBox1.Focus();
                    return;
                }
                else
                {
                    string pid = SHA256(textBox1.Text);
                    System.IO.Directory.CreateDirectory(@"E:\Archive" + @"\" + pid + "");
                    string pwd = SHA256(textBox2.Text);
                    l.reg(textBox1.Text, pwd, "nothing");
                    MessageBox.Show("ثبت نام با موفقیت انجام شد");

                    this.Hide();
                    Form1 f = new Form1();
                    f.Show();
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                textBox2.UseSystemPasswordChar = false;
            }
            else
            {
                textBox2.UseSystemPasswordChar = true;
            }
        }
    }
}
