﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;

namespace WindowsFormsApplication4
{
    public partial class Form2 : Form
    {
        DataSet1TableAdapters.file_tblTableAdapter f = new DataSet1TableAdapters.file_tblTableAdapter();
        DataSet1TableAdapters.login_tblTableAdapter l = new DataSet1TableAdapters.login_tblTableAdapter();

        public Form2()
        {
            InitializeComponent();
            //MsgBoxCheck.MessageBox dm = new MsgBoxCheck.MessageBox();
            //DialogResult dr =
            //        dm.Show(@"Software\PricklySoft\TestMsgBoxCheck",
            //        information.id, DialogResult.OK,
            //        "دوباره این سوال را از من نپرس",
            //        "برای آنکه فایل رمزگشایی یا حذف شود لازم است روی آدرس فایل در لیست باکس راست کلیک شود و ابتدا پوشه مقصد مشخص گردد سپس مجددا روی مسیر فایل راست کلیک شود و از گزینه ی رمز گشایی برای کپی کردن فایل و رمزگشایی آن در مقصد استفاده شود",
            //        "توجه",
            //        MessageBoxButtons.OK, MessageBoxIcon.Information);
            ////button1.Text = "غیرفعال";
            ////var d = f.GetDataByowner(information.id);
            ////foreach (string files in Directory.GetFiles(@"E:\Archive", "*.*"))
            ////{
            ////    for (int i = 0; i < d.Count - 1; i++)
            ////    {

            ////        if (Path.GetFileName(files) == d.Rows[i][1].ToString())
            ////        {
            ////            listBox1.Items.Add(Path.GetFileName(files));
            ////        }
            ////    }
            ////}
            string pid = Sha256(information.id);
            string[] files = Directory.GetFiles(@"E:\Archive" + @"\" + pid + "");
            listBox1.Items.Clear();
            foreach (var file in files)
            {
                listBox1.Items.Add(file);
            }
        }

        private string Sha256(string text)
        {
            StringBuilder sb = new StringBuilder();
            SHA256 hash = SHA256Managed.Create();
            Encoding enc = Encoding.UTF8;
            byte[] hashbyte = hash.ComputeHash(enc.GetBytes(text));

            foreach (byte b in hashbyte)
            {
                sb.Append(b.ToString("x2"));
            }
            return sb.ToString();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                information.fullpath = openFileDialog1.FileName;
                information.filename = openFileDialog1.SafeFileName;
                information.path = information.fullpath.Replace(information.filename, "");
                //button1.Enabled = true;
                //button1.Text = "ذخیره و رمزنگاری";
            }

            ///////////////////////////////////////////////////////////////////انتقال کپی فایل مبدا در دایرکتوری اصلی
            string pid = Sha256(information.id);
            string fname = information.filename;
            string sourcepath = information.path;
            string targetpath = @"E:\Archive\" + pid;

            string sourcefile = Path.Combine(sourcepath, fname);
            string destfile = Path.Combine(targetpath, fname);

            File.Copy(sourcefile, destfile, true);

            ///////////////////////////////////////////////////////////////////ذخیره هش فایل کپی شده در پایگاه داده و رمزنگاری فایل 
            try
            {
                var mainTitle = Text;
                Text = @"در حال رمزگذاری فایل ...";
                var filePath = targetpath + @"\" + fname + "";
                var password = information.new_pass;

                var file_bytes = File.ReadAllBytes(filePath);
                var file_hash = SHA256.Create().ComputeHash(file_bytes);
                ////////////////////////////////////////////////////////////////////////// ذخیره ی هش فایل در پایگاه داده

                f.ins(fname, filePath, file_hash.ToString(), information.id, "encrypted");

                //////////////////////////////////////////////////////////////////////////رمز نگاری فایل

                //برای آن که برنامه در هنگام عملیات رمزگذاری قفل نشود
                //  متد زیر را با استفاده از Task فراخوانی می کنیم
                await Task.Run(() => AesCryptography.EncryptFile(filePath, password));
                Text = mainTitle;
                MessageBox.Show(@"عمل رمزنگاری و درج با موفقیت انجام شد");
                string[] files = Directory.GetFiles(@"E:\Archive" + @"\" + pid + "");
                listBox1.Items.Clear();
                foreach (var file in files)
                {
                    listBox1.Items.Add(file);
                }
                //button1.Enabled = false;
                //button1.Text = "غیرفعال";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void حذففایلازپوشهیفرعیToolStripMenuItem_Click(object sender, EventArgs e)
        {

            if (System.IO.File.Exists(listBox1.SelectedItem.ToString()))
            {
                try
                {
                    System.IO.File.Delete(listBox1.SelectedItem.ToString());
                    f.del(listBox1.SelectedItem.ToString());
                    MessageBox.Show("عملیات حذف با موفقیت انجام شد");

                    string pid = Sha256(information.id);
                    string[] files = Directory.GetFiles(@"E:\Archive" + @"\" + pid + "");
                    listBox1.Items.Clear();
                    foreach (var file in files)
                    {
                        listBox1.Items.Add(file);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }


        private void button4_Click(object sender, EventArgs e)
        {
            information.items = listBox1.Items.Cast<string>().ToArray();
            this.Hide();
            changepass cp = new changepass();
            cp.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private async void رمزگشاییToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                information.path = folderBrowserDialog1.SelectedPath;
            }

            information.filename = Path.GetFileName(listBox1.SelectedItem.ToString());
            information.fullpath = listBox1.SelectedItem.ToString();
            string source = information.fullpath.Replace(information.filename, "");

            string sourcefile = Path.Combine(source, information.filename);
            string destfile = Path.Combine(information.path, information.filename);

            File.Copy(sourcefile, destfile, true);

            try
            {
                var filePath = listBox1.SelectedItem.ToString();
                var file_bytes = File.ReadAllBytes(filePath);
                var file_hash = SHA256.Create().ComputeHash(file_bytes);
                string hash = file_hash.ToString();

                var s = f.GetDataByadrs(filePath);

                if (s.Rows.Count == 0)
                {
                    MessageBox.Show("این فایل مورد حمله قرارگرفته است");
                    File.Delete(filePath);
                    f.del(Path.GetFileName(filePath));
                    string pid = Sha256(information.id);
                    string[] files = Directory.GetFiles(@"E:\Archive" + @"\" + pid + "");
                    listBox1.Items.Clear();
                    foreach (var file in files)
                    {
                        listBox1.Items.Add(file);
                    }
                    return;
                }
                else
                {
                    if (hash == s.Rows[0][3].ToString())
                    {
                        MessageBox.Show("فایل سالم است");

                        var mainTitle = Text;
                        Text = @"در حال رمزگشایی فایل ...";
                        filePath = information.path + @"\" + information.filename;
                        var password = information.new_pass;
                        // برای آن که برنامه در هنگام عملیات رمزگشایی قفل نشود
                        //  متد زیر را با استفاده از Task فراخوانی می کنیم
                        await Task.Run(() => AesCryptography.DecryptFile(filePath, password));
                        Text = mainTitle;
                        MessageBox.Show(@"عملیات رمزگشایی با موفقیت انجام شد");
                        return;

                    }

                    //else if ((hash != s.Rows[0][3].ToString()) || (information.filename != s.Rows[0][1].ToString()))
                    //{
                    //    MessageBox.Show("فایل مورد حمله قرار گرفته است");
                    //    return;
                    //}
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.GetType().ToString());
            }

        }

        private async void button2_Click(object sender, EventArgs e)
        {
            if (folderBrowserDialog1.ShowDialog() == DialogResult.OK)
            {
                information.path = folderBrowserDialog1.SelectedPath;
            }

            information.filename = Path.GetFileName(listBox1.SelectedItem.ToString());
            information.fullpath = listBox1.SelectedItem.ToString();
            string source = information.fullpath.Replace(information.filename, "");

            string sourcefile = Path.Combine(source, information.filename);
            string destfile = Path.Combine(information.path, information.filename);

            File.Copy(sourcefile, destfile, true);

            try
            {
                var filePath = listBox1.SelectedItem.ToString();
                var file_bytes = File.ReadAllBytes(filePath);
                var file_hash = SHA256.Create().ComputeHash(file_bytes);
                string hash = file_hash.ToString();

                var s = f.GetDataByadrs(filePath);

                if (s.Rows.Count == 0)
                {
                    MessageBox.Show("این فایل مورد حمله قرارگرفته است");
                    File.Delete(filePath);
                    f.del(Path.GetFileName(filePath));
                    string pid = Sha256(information.id);
                    string[] files = Directory.GetFiles(@"E:\Archive" + @"\" + pid + "");
                    listBox1.Items.Clear();
                    foreach (var file in files)
                    {
                        listBox1.Items.Add(file);
                    }
                    return;
                }
                else
                {
                    if (hash == s.Rows[0][3].ToString())
                    {
                        MessageBox.Show("فایل سالم است");

                        var mainTitle = Text;
                        Text = @"در حال رمزگشایی فایل ...";
                        filePath = information.path + @"\" + information.filename;
                        var password = information.new_pass;
                        // برای آن که برنامه در هنگام عملیات رمزگشایی قفل نشود
                        //  متد زیر را با استفاده از Task فراخوانی می کنیم
                        await Task.Run(() => AesCryptography.DecryptFile(filePath, password));
                        Text = mainTitle;
                        MessageBox.Show(@"عملیات رمزگشایی با موفقیت انجام شد");
                        return;

                    }

                    //else if ((hash != s.Rows[0][3].ToString()) || (information.filename != s.Rows[0][1].ToString()))
                    //{
                    //    MessageBox.Show("فایل مورد حمله قرار گرفته است");
                    //    return;
                    //}
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.GetType().ToString());
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (System.IO.File.Exists(listBox1.SelectedItem.ToString()))
            {
                try
                {
                    System.IO.File.Delete(listBox1.SelectedItem.ToString());
                    f.del(listBox1.SelectedItem.ToString());
                    MessageBox.Show("عملیات حذف با موفقیت انجام شد");

                    string pid = Sha256(information.id);
                    string[] files = Directory.GetFiles(@"E:\Archive" + @"\" + pid + "");
                    listBox1.Items.Clear();
                    foreach (var file in files)
                    {
                        listBox1.Items.Add(file);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }
    }
}

